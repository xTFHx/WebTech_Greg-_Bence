function hozzaad() {
    let szovegbox = document.getElementById("teendoszoveg");
    let szoveg = szovegbox.value;

    let lista = document.createElement("li");
    lista.textContent = szoveg;
    document.getElementById("teendolista").appendChild(lista);

    lista.onclick = function torol() {
        this.style.textDecoration = "line-through";
    }

}